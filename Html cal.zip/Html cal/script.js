let display = document.getElementById('display');
let expression = '';

function appendToDisplay(value) {
    expression += value;
    display.textContent = expression;
}

function calculate() {
    try {
        expression = eval(expression).toString();
        display.textContent = expression;
    } catch (error) {
        display.textContent = 'Error';
        expression = '';
    }
}